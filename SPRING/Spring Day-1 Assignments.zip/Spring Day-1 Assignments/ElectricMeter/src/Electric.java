public class Electric {
	public int meterno;
	public int inireading;
	public int currentreading;
	public String colour;
	public int getMeterno() {
		return meterno;
	}
	public void setMeterno(int meterno) {
		this.meterno = meterno;
	}
	public int getInireading() {
		return inireading;
	}
	public void setInireading(int inireading) {
		this.inireading = inireading;
	}
	public int getCurrentreading() {
		return currentreading;
	}
	public void setCurrentreading(int currentreading) {
		this.currentreading = currentreading;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}

}
