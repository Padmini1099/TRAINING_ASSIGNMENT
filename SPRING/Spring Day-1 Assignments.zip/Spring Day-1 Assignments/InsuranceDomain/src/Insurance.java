public class Insurance {
	public int insuranceid;
	public String name;
	public String type;
	public int ammount;
	public int getInsuranceid() {
		return insuranceid;
	}
	public void setInsuranceid(int insuranceid) {
		this.insuranceid = insuranceid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAmmount() {
		return ammount;
	}
	public void setAmmount(int ammount) {
		this.ammount = ammount;
	}
	
	

}
