public class FlightBooking {
	public String name;
	public String email;
	public String fromlocation;
	public String tolocation;
	public int seatsavailable;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFromlocation() {
		return fromlocation;
	}
	public void setFromlocation(String fromlocation) {
		this.fromlocation = fromlocation;
	}
	public String getTolocation() {
		return tolocation;
	}
	public void setTolocation(String tolocation) {
		this.tolocation = tolocation;
	}
	public int getSeatsavailable() {
		return seatsavailable;
	}
	public void setSeatsavailable(int seatsavailable) {
		this.seatsavailable = seatsavailable;
	}
	
	

}
